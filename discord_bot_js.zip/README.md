# Advanced Discord Bot (Node.js)

An ultra-advanced, feature-rich Discord bot built with `discord.js`.

## Features
- **Moderation**: `!kick`, `!ban`, `!purge`, `!warn`
- **Tickets**: `!newticket` for private support channels.
- **Jailing**: `!jail` to restrict users.
- **Music**: `!play` to stream music from YouTube.
- **Giveaways**: `!gstart` for automated giveaways.

## Setup
1. **Install Node.js**: Ensure you have Node.js 18.x or higher.
2. **Install Dependencies**:
   ```bash
   pnpm install
   ```
3. **Configure Environment**:
   Create a `.env` file in the root directory:
   ```env
   DISCORD_BOT_TOKEN=your_token_here
   DEVELOPER_ID=your_discord_user_id
   ```
4. **Run the Bot**:
   ```bash
   node src/index.js
   ```

## Requirements
- **FFmpeg**: Must be installed on your system for music playback.
- **Intents**: Enable all Privileged Gateway Intents in the Discord Developer Portal.
