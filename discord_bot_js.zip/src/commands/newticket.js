import { ChannelType, PermissionFlagsBits } from 'discord.js';

export default {
    data: {
        name: 'newticket',
        description: 'Creates a new support ticket.',
    },
    async execute(message, args) {
        const guild = message.guild;
        const member = message.member;
        const topic = args.join(' ') || 'No topic provided';

        try {
            const ticketChannel = await guild.channels.create({
                name: `ticket-${member.user.username}`,
                type: ChannelType.GuildText,
                permissionOverwrites: [
                    {
                        id: guild.id,
                        deny: [PermissionFlagsBits.ViewChannel],
                    },
                    {
                        id: member.id,
                        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
                    },
                    {
                        id: message.client.user.id,
                        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
                    },
                ],
            });

            await ticketChannel.send(`Welcome ${member}! Your ticket has been created. Topic: ${topic}`);
            await message.reply(`Your ticket has been created: ${ticketChannel}`);
        } catch (error) {
            console.error(error);
            message.reply('An error occurred while creating the ticket.');
        }
    },
};
