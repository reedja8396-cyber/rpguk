import { EmbedBuilder } from 'discord.js';
import ms from 'ms'; // We need to add this to dependencies

export default {
    data: {
        name: 'gstart',
        description: 'Starts a giveaway.',
    },
    async execute(message, args) {
        if (!message.member.permissions.has('ManageGuild')) {
            return message.reply('You do not have permission to start giveaways.');
        }

        const durationStr = args[0];
        const winnersCount = parseInt(args[1]);
        const prize = args.slice(2).join(' ');

        if (!durationStr || isNaN(winnersCount) || !prize) {
            return message.reply('Usage: !gstart <duration> <winners> <prize>');
        }

        const duration = ms(durationStr);
        if (!duration) return message.reply('Invalid duration format (e.g., 1h, 30m).');

        const embed = new EmbedBuilder()
            .setTitle('🎉 GIVEAWAY 🎉')
            .setDescription(`Prize: **${prize}**\nWinners: ${winnersCount}\nEnds in: ${durationStr}`)
            .setColor('Green')
            .setTimestamp(Date.now() + duration);

        const gMessage = await message.channel.send({ embeds: [embed] });
        await gMessage.react('🎉');

        setTimeout(async () => {
            const reaction = gMessage.reactions.cache.get('🎉');
            const users = await reaction.users.fetch();
            const entries = users.filter(u => !u.bot).map(u => u);

            if (entries.length === 0) {
                return message.channel.send('No one entered the giveaway.');
            }

            const winners = [];
            for (let i = 0; i < Math.min(winnersCount, entries.length); i++) {
                const winner = entries.splice(Math.floor(Math.random() * entries.length), 1)[0];
                winners.push(winner);
            }

            message.channel.send(`Congratulations ${winners.join(', ')}! You won **${prize}**!`);
        }, duration);
    },
};
