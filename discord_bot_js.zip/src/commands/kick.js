import { PermissionFlagsBits } from 'discord.js';

export default {
    data: {
        name: 'kick',
        description: 'Kicks a member from the server.',
    },
    async execute(message, args) {
        if (!message.member.permissions.has(PermissionFlagsBits.KickMembers)) {
            return message.reply('You do not have permission to use this command.');
        }

        const target = message.mentions.members.first();
        if (!target) return message.reply('Please mention a member to kick.');

        const reason = args.slice(1).join(' ') || 'No reason provided';

        try {
            await target.kick(reason);
            message.channel.send(`${target.user.tag} has been kicked. Reason: ${reason}`);
        } catch (error) {
            console.error(error);
            message.reply('I was unable to kick that member.');
        }
    },
};
