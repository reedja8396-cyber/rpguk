import { PermissionFlagsBits } from 'discord.js';

export default {
    data: {
        name: 'warn',
        description: 'Warns a member.',
    },
    async execute(message, args) {
        if (!message.member.permissions.has(PermissionFlagsBits.ManageMessages)) {
            return message.reply('You do not have permission to use this command.');
        }

        const target = message.mentions.members.first();
        if (!target) return message.reply('Please mention a member to warn.');

        const reason = args.slice(1).join(' ') || 'No reason provided';

        try {
            await message.channel.send(`**Warning issued to ${target.user.tag}**\nReason: ${reason}`);
            await target.send(`You have been warned in ${message.guild.name} for: ${reason}`).catch(() => {
                message.channel.send('Could not DM the user about the warning.');
            });
        } catch (error) {
            console.error(error);
            message.reply('An error occurred while trying to warn the member.');
        }
    },
};
