import { PermissionFlagsBits } from 'discord.js';

export default {
    data: {
        name: 'ban',
        description: 'Bans a member from the server.',
    },
    async execute(message, args) {
        if (!message.member.permissions.has(PermissionFlagsBits.BanMembers)) {
            return message.reply('You do not have permission to use this command.');
        }

        const target = message.mentions.members.first();
        if (!target) return message.reply('Please mention a member to ban.');

        const reason = args.slice(1).join(' ') || 'No reason provided';

        try {
            await target.ban({ reason });
            message.channel.send(`${target.user.tag} has been banned. Reason: ${reason}`);
        } catch (error) {
            console.error(error);
            message.reply('I was unable to ban that member.');
        }
    },
};
