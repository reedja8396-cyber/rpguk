import { PermissionFlagsBits } from 'discord.js';

export default {
    data: {
        name: 'purge',
        description: 'Deletes a specified number of messages.',
    },
    async execute(message, args) {
        if (!message.member.permissions.has(PermissionFlagsBits.ManageMessages)) {
            return message.reply('You do not have permission to use this command.');
        }

        const amount = parseInt(args[0]);
        if (isNaN(amount) || amount < 1 || amount > 100) {
            return message.reply('Please provide a number between 1 and 100.');
        }

        try {
            const deleted = await message.channel.bulkDelete(amount + 1, true);
            const msg = await message.channel.send(`Successfully deleted ${deleted.size - 1} messages.`);
            setTimeout(() => msg.delete(), 5000);
        } catch (error) {
            console.error(error);
            message.reply('An error occurred while trying to purge messages.');
        }
    },
};
