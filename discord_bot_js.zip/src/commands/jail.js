import { PermissionFlagsBits, ChannelType } from 'discord.js';

export default {
    data: {
        name: 'jail',
        description: 'Jails a member.',
    },
    async execute(message, args) {
        if (!message.member.permissions.has(PermissionFlagsBits.KickMembers)) {
            return message.reply('You do not have permission to use this command.');
        }

        const target = message.mentions.members.first();
        if (!target) return message.reply('Please mention a member to jail.');

        const reason = args.slice(1).join(' ') || 'No reason provided';

        try {
            let jailRole = message.guild.roles.cache.find(r => r.name === 'Jailed');
            if (!jailRole) {
                jailRole = await message.guild.roles.create({
                    name: 'Jailed',
                    permissions: [],
                    reason: 'Required for jail command'
                });
                
                // Set permissions for all channels
                message.guild.channels.cache.forEach(async (channel) => {
                    await channel.permissionOverwrites.edit(jailRole, {
                        ViewChannel: false,
                        SendMessages: false,
                        Connect: false
                    }).catch(console.error);
                });
            }

            let jailChannel = message.guild.channels.cache.find(c => c.name === 'jail');
            if (!jailChannel) {
                jailChannel = await message.guild.channels.create({
                    name: 'jail',
                    type: ChannelType.GuildText,
                    permissionOverwrites: [
                        { id: message.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
                        { id: jailRole.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] }
                    ]
                });
            }

            // Save original roles (conceptually, in a real bot use a DB)
            // For now, just swap roles
            await target.roles.set([jailRole], reason);
            
            await jailChannel.send(`${target} has been jailed by ${message.author}. Reason: ${reason}`);
            await message.reply(`${target.user.tag} has been jailed.`);
        } catch (error) {
            console.error(error);
            message.reply('An error occurred while trying to jail the member.');
        }
    },
};
