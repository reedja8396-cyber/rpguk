import { joinVoiceChannel, createAudioPlayer, createAudioResource, AudioPlayerStatus } from '@discordjs/voice';
import play from 'play-dl';

export default {
    data: {
        name: 'play',
        description: 'Plays a song from YouTube.',
    },
    async execute(message, args) {
        const query = args.join(' ');
        if (!query) return message.reply('Please provide a song name or URL.');

        const voiceChannel = message.member.voice.channel;
        if (!voiceChannel) return message.reply('You need to be in a voice channel to play music!');

        try {
            const connection = joinVoiceChannel({
                channelId: voiceChannel.id,
                guildId: message.guild.id,
                adapterCreator: message.guild.voiceAdapterCreator,
            });

            const yt_info = await play.search(query, { limit: 1 });
            const stream = await play.stream(yt_info[0].url);
            const resource = createAudioResource(stream.stream, { inputType: stream.type });
            const player = createAudioPlayer();

            player.play(resource);
            connection.subscribe(player);

            await message.reply(`Now playing: **${yt_info[0].title}**`);

            player.on(AudioPlayerStatus.Idle, () => {
                connection.destroy();
            });
        } catch (error) {
            console.error(error);
            message.reply('An error occurred while trying to play music.');
        }
    },
};
